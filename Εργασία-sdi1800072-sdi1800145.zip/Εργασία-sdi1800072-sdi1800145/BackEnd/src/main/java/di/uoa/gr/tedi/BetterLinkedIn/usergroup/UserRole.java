package di.uoa.gr.tedi.BetterLinkedIn.usergroup;

public enum UserRole {
    USER,
    ADMIN
}
