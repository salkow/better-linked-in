/*
package di.uoa.gr.tedi.BetterLinkedIn.adverts;

import lombok.Getter;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Getter
public class Skill {
    @Id
    private final String skill;

    pr

    public Skill(String skill) {
        this.skill = skill;
    }

    public Skill() {
        skill = "";
    }
}*/
