package di.uoa.gr.tedi.BetterLinkedIn.utils;

import lombok.Data;

@Data
public class WBool {
    private Boolean response;
}