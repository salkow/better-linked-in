package di.uoa.gr.tedi.BetterLinkedIn.utils;

import lombok.AllArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
public class IsFriend {
    private Boolean isFriend;
}
