package di.uoa.gr.tedi.BetterLinkedIn.friends;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class FriendRequest {
    private Long id;
    private String name;
}
