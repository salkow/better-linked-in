package di.uoa.gr.tedi.BetterLinkedIn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BetterLinkedInApplicationTests {

	@Test
	void contextLoads() {
	}

}
